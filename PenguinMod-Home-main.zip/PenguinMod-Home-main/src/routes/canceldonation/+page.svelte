<script>
    import { onMount } from "svelte";

    onMount(() => {
        location.pathname = "/donate";
    });
</script>
