<script>
    import { onMount } from "svelte";

    onMount(() => {
        location.pathname = "/sucessdonation";
    });
</script>
