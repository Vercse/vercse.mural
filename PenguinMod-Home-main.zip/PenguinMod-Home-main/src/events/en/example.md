# Example Event

```host
my dog
```
```collab
a cool company
```

this is so
epic

this is not a real event, simply just made for testing