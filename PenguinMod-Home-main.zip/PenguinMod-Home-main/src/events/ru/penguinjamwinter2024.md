# Winter 2024 PenguinJam

<!-- Try not to touch the ```host or ```collab sections, they are direct user links -->
<!-- You should translate ```warning sections though. -->
```host
puzzlingggg
```

Добро пожаловать на первый PenguinJam на этом сайте!

Это будет повторяющееся событие, которое будет проходить время от времени. Если вы упустите свой шанс сейчас, можете участвовать в будущем!

*(Мы изначально провели самый первый PenguinJam в другом месте.)*

# PenguinJam активен!
Тема PenguinJam это:
**Слишком Много**

Несколько примеров для начала: слишком много машин на большой скорости, слишком много подарков под елкой, слишком много рисков или слишком много людей для обслуживания в ресторане.

Создайте и опубликуйте проект до ***16 декабря в 22:00 по московскому времени (МСК)***!

Опубликуйте проекты на PenguinJam  **используя тег [#penguinjam2](/search?q=%23penguinjam2) в названии или примечаниях.**

## Что такое PenguinJam?
PenguinJam - это геймджем, который начнётся ***16 декабря в 22:00 по московскому времени (МСК)***.

Прокрутите до раздела “Что такое Геймджем?”,если вы не знаете что это.

Опубликуйте проекты на PenguinJam  **используя тег [#penguinjam2](/search?q=%23penguinjam2) в названии или примечаниях.**

## Какая тема?
Тема PenguinJam это:
**Слишком Много**

Несколько примеров для начала: слишком много машин на большой скорости, слишком много подарков под елкой, слишком много рисков или слишком много людей для обслуживания в ресторане.

Создайте и опубликуйте проект до ***16 декабря в 22:00 по московскому времени (МСК)***!

Участвуйте, если хотите получить один из значков:
<div style="display:flex;flex-direction:row">
    <img src="https://penguinmod.com/badges/participant.png" width="48"></img>
    <img src="https://penguinmod.com/badges/eventwinner.png" width="48"></img>
    <img src="https://penguinmod.com/badges/penguinjambronze.png" width="48"></img>
    <img src="https://penguinmod.com/badges/penguinjamsilver.png" width="48"></img>
    <img src="https://penguinmod.com/badges/penguinjamgold.png" width="48"></img>
    <img src="https://penguinmod.com/badges/penguinjamobsidian.png" width="48"></img>
    <img src="https://penguinmod.com/badges/penguinjamplatinum.png" width="48"></img>
</div>
<br></br>

## Что такое Геймджем?
Как будет работать наш PenguinJam:

### Мы раскроем тему
Вам будет необходимо создать проект PenguinMod согласно теме.

Вы можете создать проект, который каким-либо образом связан с темой, которую мы выдаем. **Это должно быть большая часть вашего проекта.**

Тема будет раскрыта ***16 декабря в 22:00 по московскому времени (МСК)***.

### Опубликование проекта
Опубликуйте проекты согласно теме на PenguinJam **используя тег #penguinjam2 в названии или примечаниях.**

Убедитесь что, вы опубликовали проект до ***24 декабря в 22:00 по московскому времени (МСК)***! Не публикуйте их позже.

### Мы оцениваем ваши проекты
Сотрудники и разработчики посмотрят все опубликованные проекты и проверят, что сделал каждый.

Чем более творчески вы подаёте тему, тем лучше.

В любом случае, ваши игры **всё ещё должны быть в основном весёлыми.**

### Мы выдаём награды
Мы выберем пять самых выдающихся игр, и лучшие создатели получат значки на свой профиль!

Значки будут выданы через некоторое время **Пожалуйста, не давите на нас если мы не выдадим вам значок вовремя, мы можем быть заняты другими важными делами.**

<img src="https://penguinmod.com/badges/participant.png" width="48"></img>
Участник События будет выдан всем. (ну, или почти всем, скорее всего, не будем учитывать проекты низкого качества)

<img src="https://penguinmod.com/badges/eventwinner.png" width="48"></img>
Победитель События будет выдана создателям в Топ 5 Проектов.

<img src="https://penguinmod.com/badges/penguinjambronze.png" width="48"></img>
PenguinJam: Бронза будет выдана создателю проекта на 3-м месте.

<img src="https://penguinmod.com/badges/penguinjamsilver.png" width="48"></img>
PenguinJam: Серебро будет выдано создателю проекта на 2-м месте.

<img src="https://penguinmod.com/badges/penguinjamgold.png" width="48"></img>
PenguinJam: Золото будет выдано создатель проекта на 1-м месте

<img src="https://penguinmod.com/badges/penguinjamobsidian.png" width="48"></img>
PenguinJam: Обсидиан будет выдан создателю проекта на 3-м месте в этом и прошлом PenguinJam.

<img src="https://penguinmod.com/badges/penguinjamplatinum.png" width="48"></img>
PenguinJam: Платина будет выдана создателю проекта на 3-м месте в этом и 2-х прошлых PenguinJam.
