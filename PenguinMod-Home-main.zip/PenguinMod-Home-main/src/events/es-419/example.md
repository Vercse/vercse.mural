# Evento de ejemplo

```host
mi perro
```

no se como poner las accentos en Windows 10, y mi espanol no esta bueno

esto evento es nomas para experimento, no es por los todos a ver